﻿using System;

namespace ObservableCollectionExamples
{
       class Program
    {
        static void Main(string[] args)
        {
            ObservableCollection<T>

        ObservableCollection<string> names = new ObservableCollection<string>();
            names.Add("John");
            names.Add("Mohammed");
            names.Add("Juliyan");
            names.Add("Kounde");

            Console.WriteLine("Names: " + string.Join(", ", names));

            Notification on ObservableCollection<T>

            ObservableCollection<string> items = new ObservableCollection<string>();

            items.CollectionChanged += _ItemCangeNotifier;

            items.Add("Ahmed");
            items.Add("Salem");
            items.Add("Munir");
            items.Add("Ibrahim");
            Console.WriteLine("Currnet List Show: " + string.Join(", ", items));
            items.Remove("Munir");

            items[2] = "Mohammed";

            items.Insert(1, "Jamal");

            items.Move(0, 2);

            Console.WriteLine("Final List Show: " + string.Join(", ", items));


        }
        static void _ItemCangeNotifier(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    Console.WriteLine("Added: ");
                    foreach (var item in e.NewItems)
                    {
                        Console.WriteLine(item.ToString());
                    }
                    break;
                case NotifyCollectionChangedAction.Remove:
                    Console.WriteLine("Removed: ");

                    foreach (var removed in e.OldItems)
                    {
                        Console.WriteLine(removed.ToString());
                    }
                    break;
                case NotifyCollectionChangedAction.Replace:
                    Console.WriteLine("Replaced: ");

                    foreach (var old in e.OldItems)
                    {
                        Console.WriteLine($"{old.ToString()}");
                    }
                    Console.WriteLine("By");

                    foreach (var New in e.NewItems)
                    {
                        Console.WriteLine(New.ToString());
                    }
                    break;
                case NotifyCollectionChangedAction.Move:
                    Console.WriteLine($"Moved {e?.NewItems[0]} from index {e.OldStartingIndex} to index {e.NewStartingIndex}");
                    break;

                default:
                    break;
            }
        }
    }
}