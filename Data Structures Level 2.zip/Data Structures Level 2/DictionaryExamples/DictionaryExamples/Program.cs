﻿using System;

namespace DictionaryExamples
{
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary

        Dictionary<int, string> dict = new Dictionary<int, string>();

            dict.Add(1, "one");
            dict.Add(2, "two");
            dict.Add(3, "three");
            dict.Add(4, "four");
            dict.Add(5, "five");


            dict[1] = "uno";
            foreach (var entry in dict)
            {
                Console.WriteLine("Key: " + entry.Key + " Value: " + entry.Value);
            }

            dict.Remove(3);
            Console.WriteLine("-------------------------------------------------");

            dict[1] = "uno";
            foreach (var entry in dict)
            {
                Console.WriteLine("Key: " + entry.Key + " Value: " + entry.Value);
            }

            using TryGetValue

        Dictionary<string, int> fruit = new Dictionary<string, int>();
            fruit.Add("Apple", 5);
            fruit.Add("Orange", 7);

            if (fruit.TryGetValue("Apple", out int quantity))
            {
                Console.WriteLine("Apple quantity is " + quantity);
            }
            else { Console.WriteLine("There is no apple available"); }

            using LINQ with Dictionaries

        Dictionary<string, int> fruit = new Dictionary<string, int>();
            fruit.Add("Apple", 5);
            fruit.Add("Orange", 7);
            fruit.Add("Mango", 2);
            var fruitInfo = fruit.Select(kvp => new { kvp.Key, kvp.Value });

            var getAllFruit = fruit.Select(x => new { x.Key, x.Value });

            foreach (var f in getAllFruit)
            {
                Console.WriteLine("Name: " + f.Key.ToString() + " Amount: " + f.Value.ToString());
            }

            Console.WriteLine("-------------------");
            var filterdFruit = fruit.Where(x => x.Value > 5);

            foreach (var f in filterdFruit)
            {
                Console.WriteLine(f.ToString());
            }

            var orderAceFruites = fruit.OrderBy(x => x.Value);
            Console.WriteLine("-------------------");
            foreach (var f in orderAceFruites)
            {
                Console.WriteLine(f.ToString());
            }

            var orderDecFruites = fruit.OrderByDescending(x => x.Value);
            Console.WriteLine("-------------------");
            foreach (var f in orderDecFruites)
            {
                Console.WriteLine(f.ToString());
            }

            var totalSum = fruit.Sum(x => x.Value);
            Console.WriteLine("-------------------");
            Console.WriteLine("Total Fruit Sum: " + totalSum.ToString());

            var maxFruit = fruit.Max(x => x.Value);
            Console.WriteLine("-------------------");
            Console.WriteLine("Highest fruit amount: " + maxFruit.ToString());

            var minFruit = fruit.Min(x => x.Value);
            Console.WriteLine("-------------------");
            Console.WriteLine("Lowest fruit amount: " + minFruit.ToString());

            var avgFruit = (int)fruit.Average(x => x.Value);
            Console.WriteLine("-------------------");
            Console.WriteLine("Average fruit amount: " + avgFruit.ToString());


            Advanced LINQ operations in Dictionary



        Dictionary<string, string> fruits = new Dictionary<string, string>();
            fruits.Add("Apple", "Tree");
            fruits.Add("Orange", "Tree");
            fruits.Add("Mango", "Tree");
            fruits.Add("Carrot", "Vegetable");
            fruits.Add("Coconut", "Tree");
            fruits.Add("Cabage", "Vegetable");
            fruits.Add("BlackSoda", "Herb");
            fruits.Add("Tomato", "Vegetable");
            fruits.Add("Sesem", "Herb");


            var groub = fruits.GroupBy(x => x.Value);

            foreach (var category in groub)
            {
                Console.WriteLine("Category: " + category.Key);

                foreach (var fruit in category)
                {
                    Console.WriteLine("______ " + fruit.Key);
                }
            }
            //LINQ methods compination

            Dictionary<string, int> fruitcol = new Dictionary<string, int>();
            fruitcol.Add("Apple", 5);
            fruitcol.Add("Orange", 7);
            fruitcol.Add("Mango", 2);
            fruitcol.Add("Banana", 9);

            var combination = fruitcol
                .Select(f => new { f.Key, f.Value })
                .OrderBy(f => f.Key)
                .Where(f => f.Value > 2);
            Console.WriteLine("-------------------");
            foreach (var f in combination)
            {
                Console.WriteLine(f.Key + " - " + f.Value);
            }
        }
    }
}