﻿using System;

namespace SortedDictionary
{
    class Program
    {
        static void Main(string[] args)
        {
           // SortedDictionary<Tkey, Tval>

            SortedDictionary<int, string> keyValuePairs = new SortedDictionary<int, string>();

            keyValuePairs.Add(3, "Banana");
            keyValuePairs.Add(1, "Mango");
            keyValuePairs.Add(2, "Orange");

            Console.WriteLine("StoredDictionary: " + string.Join(", ", keyValuePairs));

            Console.WriteLine("value of 1: " + keyValuePairs[1]);
            Console.WriteLine("value of 2: " + keyValuePairs[2]);

            keyValuePairs.Remove(1);

            Console.WriteLine(string.Join(", ", keyValuePairs));

            Console.WriteLine("Does sortedDictionary contains Cherry:" + keyValuePairs.ContainsValue("Cherry")); //false
            Console.WriteLine("Does sortedDictionary contains Orange:" + keyValuePairs.ContainsValue("Orange")); //true
        }
    }
}