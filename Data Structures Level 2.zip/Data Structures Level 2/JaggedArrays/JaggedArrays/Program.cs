﻿using System;

namespace JaggedArrays
{
    class Program
    {
        static void Main(string[] args)
        {


            Jagged Array

int[][] matrix = new int[3][];


            // Populate each row with arrays of varying sizes
            matrix[0] = new int[] { 1, 2, 3 };
            matrix[1] = new int[] { 4, 5 };
            matrix[2] = new int[] { 6, 7, 8, 9 };


            // Display the matrix
            for (int row = 0; row < matrix.Length; row++)
            {
                Console.Write("Row " + row + ": ");
                for (int col = 0; col < matrix[row].Length; col++)
                {
                    Console.Write(matrix[row][col] + " ");
                }
                if (row < matrix.Length - 1)
                {
                    Console.WriteLine("Press any key for next row:");
                    Console.ReadKey();
                }
            }



            int[][] b = [[1, 2, 3], [3, 4, 5, 6, 7], [8, 9]];


            // Addveanced LINQ operations in Jagged Array

            var totalSum = b.SelectMany(flat => flat).Sum();
            Console.WriteLine("Total Sum of all sub arrays: " + totalSum);

            var biggestNum = b.SelectMany(flat => flat).Max();
            Console.WriteLine("The biggest Number: " + biggestNum);

            var smallestNum = b.SelectMany(falt => falt).Min();
            Console.WriteLine("The smallest Number: " + smallestNum);

            // Filter arrays having more than 3 elements and select their first element

            var firstElements = b.Where(arr => arr.Length <= 3)
                .Select(arr => arr.First());
            Console.WriteLine("First Elements: " + string.Join(", ", firstElements));
        }
    }
}