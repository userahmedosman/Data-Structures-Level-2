﻿using System;
using System.Collections.Generic;



namespace minHeapDataStructure
{
    class Program
    {
        public static void Main(string[] args)
        {
            //minHeap Data Structure
            MinHeap minHeap = new MinHeap();

            minHeap.Insert(10);
            minHeap.Insert(20);
            minHeap.Insert(5);
            minHeap.Insert(6);
            minHeap.Insert(8);
            minHeap.Insert(15);
            minHeap.Insert(30);

            Console.WriteLine("minHeap after insertions:");
            minHeap.DisplayminHeap();
            minHeap.Insert(7);
            Console.WriteLine("after num 7 inserted");
            minHeap.DisplayminHeap();

            Console.WriteLine("\n MAX HEAP \n");
            MaxHeap maxHeap = new MaxHeap();
            maxHeap.Insert(10);
            maxHeap.Insert(20);
            maxHeap.Insert(5);
            maxHeap.Insert(6);
            maxHeap.Insert(8);
            maxHeap.Insert(15);
            maxHeap.Insert(30);

            Console.WriteLine("MaxHeap after insertions:");
            maxHeap.DisplayMaxHeap();
            maxHeap.Insert(7);
            Console.WriteLine("after num 7 inserted");
            maxHeap.DisplayMaxHeap();


        }
    }

    public class MinHeap
    {
        private List<int> minHeap;
        public MinHeap()
        {
            minHeap = new List<int>();
        }
        public void Insert(int value)
        {
            minHeap.Add(value);
            minHeapifyUp(minHeap.Count - 1);
        }
        public int ExtractMin()
        {
            if (minHeap.Count == 0) throw new InvalidOperationException("minHeap is empty.");
            int min = minHeap[0];
            minHeap[0] = minHeap[minHeap.Count - 1];
            minHeap.RemoveAt(minHeap.Count - 1);
            minHeapifyDown(0);
            return min;
        }
        private void minHeapifyUp(int index)
        {
            while (index > 0)
            {
                int parentIndex = (index - 1) / 2;
                if (minHeap[index] >= minHeap[parentIndex]) break;
                Swap(index, parentIndex);
                index = parentIndex;
            }
        }
        private void minHeapifyDown(int index)
        {
            int lastIndex = minHeap.Count - 1;
            while (index < lastIndex)
            {
                int leftChildIndex = 2 * index + 1;
                int rightChildIndex = 2 * index + 2;

                int smallestIndex = index;
                if (leftChildIndex <= lastIndex && minHeap[leftChildIndex] < minHeap[smallestIndex])
                    smallestIndex = leftChildIndex;
                if (rightChildIndex <= lastIndex && minHeap[rightChildIndex] < minHeap[smallestIndex])
                    smallestIndex = rightChildIndex;
                if (smallestIndex == index) break;
                Swap(index, smallestIndex);
                index = smallestIndex;
            }
        }
        public int Peek()
        {
            if (minHeap.Count == 0) throw new InvalidOperationException("minHeap is empty.");
            return minHeap[0];
        }

        private void Swap(int index, int parentIndex)
        {
            (minHeap[index], minHeap[parentIndex]) = (minHeap[parentIndex], minHeap[index]);
        }

        public void DisplayminHeap()
        {
            foreach (var item in minHeap)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }

    }

    public class MaxHeap
    {
        private List<int> maxHeap;
        public MaxHeap()
        {
            maxHeap = new List<int>();
        }
        public void Insert(int value)
        {
            maxHeap.Add(value);
            maxHeapifyUp(maxHeap.Count - 1);
        }
        public int ExtractMax()
        {
            if (maxHeap.Count == 0) throw new InvalidOperationException("maxHeap is empty.");
            int max = maxHeap[0];
            maxHeap[0] = maxHeap[maxHeap.Count - 1];
            maxHeap.RemoveAt(maxHeap.Count - 1);
            maxHeapifyDown(0);
            return max;
        }
        private void maxHeapifyUp(int index)
        {
            while (index > 0)
            {
                int parentIndex = (index - 1) / 2;
                if (maxHeap[index] <= maxHeap[parentIndex]) break;
                Swap(index, parentIndex);
                index = parentIndex;
            }
        }
        private void maxHeapifyDown(int index)
        {
            int lastIndex = maxHeap.Count - 1;
            while (index < lastIndex)
            {
                int leftChildIndex = 2 * index + 1;
                int rightChildIndex = 2 * index + 2;
                int largestIndex = index;
                if (leftChildIndex <= lastIndex && maxHeap[leftChildIndex] > maxHeap[largestIndex])
                    largestIndex = leftChildIndex;
                if (rightChildIndex <= lastIndex && maxHeap[rightChildIndex] > maxHeap[largestIndex])
                    largestIndex = rightChildIndex;
                if (largestIndex == index) break;
                Swap(index, largestIndex);
                index = largestIndex;
            }
        }
        public int Peek()
        {
            if (maxHeap.Count == 0) throw new InvalidOperationException("maxHeap is empty.");
            return maxHeap[0];
        }
        private void Swap(int index, int parentIndex)
        {
            (maxHeap[index], maxHeap[parentIndex]) = (maxHeap[parentIndex], maxHeap[index]);
        }

        public void DisplayMaxHeap()
        {
            foreach (var item in maxHeap)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }
    }
}