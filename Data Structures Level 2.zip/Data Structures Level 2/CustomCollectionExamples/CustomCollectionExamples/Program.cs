﻿using System;

namespace CustomCollectionExamples {    
    class Program
    {
        static void Main(string[] args)
        {
            // Example usage of the custom collection
            IEnumerable<T> and IEnumerable

        var enumerable = new MyEnumerable<string>();
            enumerable.Add("Apple");
            enumerable.Add("Banana");
            enumerable.Add("Cherry");
            enumerable.Add("Mango");
            enumerable.Add("Orange");
            enumerable.Add("Pineapple");
            enumerable.Remove("Banana");

            foreach (var item in enumerable)
            {
                Console.WriteLine(item);
            }


            ICollection<T> and ICollection

           var collection = new MyCollection<int>();
            collection.Add(10);
            collection.Add(25);
            collection.Add(30);
            collection.Add(40);
            collection.Add(50);


            foreach (var item in collection)
            {
                Console.WriteLine(item);
            }

            var itemsCount = collection.Count;
            Console.WriteLine("Total items in collection: " + itemsCount);

            int[] array = new int[collection.Count];

            collection.CopyTo(array, 0);

            Console.WriteLine("Items copied to array: " + string.Join(", ", array));

            IList<T>


           var mylist = new MyIList<string>();

            mylist.Add("one");
            mylist.Add("two");
            mylist.Add("three");
            mylist.Add("four");
            mylist.Insert(1, "inserted");
            for (int i = 0; i < mylist.Count; i++)
            {
                Console.WriteLine(mylist[i]);
            }
            mylist.RemoveAt(1);

            mylist[0] = "updated one";

            for (int i = 0; i < mylist.Count; i++)
            {
                Console.WriteLine(mylist[i]);
            }


            IDictionary<TKey, TValue>

           var dictionary = new myDictionary<int, string>();
            dictionary.Add(1, "Apple");
            dictionary.Add(2, "Banana");
            dictionary.Add(3, "Cherry");
            dictionary.Add(4, "Date");

            Console.WriteLine("Dictionary items:" + string.Join(", ", dictionary.Values));

            if (dictionary.TryGetValue(5, out string value))
            {
                Console.WriteLine("Value for key 2: " + value);
            }
            else
            {
                Console.WriteLine("Key not found.");
            }


            dictionary[5] = "Elderberry";

            Console.WriteLine("Dictionary items after adding key 5: " + string.Join(", ", dictionary.Values));

            dictionary.Remove(2);

            Console.WriteLine("Dictionary items after removing key 2: " + string.Join(", ", dictionary.Values));

            dictionary.Clear();
            Console.WriteLine("Dictionary items after clearing: " + string.Join(", ", dictionary.Values));

            IComparable

            var std1 = new Students(1, "Ahmed", 25);
            var std2 = new Students(2, "Salem", 18);
            var std3 = new Students(3, "Ikram", 32);
            var std4 = new Students(4, "Ahmed", 22);
            var std5 = new Students(5, "", 10);


            var result = std1.CompareTo(std5);

            if (result == 0)
            {

                Console.WriteLine("Yes they are identical");
            }
            else if (result == -1)
            {
                Console.WriteLine("No they are different");

            }
            else
            {
                Console.WriteLine("Null object");
            }

            var order = new Order();
            var order2 = new Order();
            var buyer = new Customer();
            var buyer2 = new Customer();

            buyer.Name = "Ahmed";


            buyer2.Name = "Ahmed";

            order.Buyer = buyer;
            order2.Buyer = buyer2;
            var co = buyer.CompareTo(buyer2);
            var comp = order.CompareTo(order2);

            Console.WriteLine("Result: " + comp);

            /* --description--
             * if buyer and buyer2 contain the same Name with identical values, the compare will be 0 (means equal)
             * if buyer and buyer2 are equal, then the CompareTo method in Order class will return 0 (menas they are equal objects)
             * if buyer and buyer2 are not equal, then the CompareTo method in Order class will return -1 (means they are not equal objects)
             * if buyer or buyer2 is null, then the CompareTo method in Order class will return 1 (means the other object is greater than null)
             * **/
        }

        public class MyEnumerable<T> : IEnumerable<T>
        {
            List<T> _items = new List<T>();

            public void Add(T item)
            {
                _items.Add(item);

            }
            public bool Remove(T item)
            {
                return _items.Remove(item);
            }
            public IEnumerator<T> GetEnumerator()
            {
                foreach (var item in _items)
                {
                    yield return item;
                }
            }
            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        }

        public class MyCollection<T> : ICollection<T>
        {
            public List<T> _items = new List<T>();

            public int Count => _items.Count;

            public bool IsReadOnly => false;

            public void Add(T item)
            {
                _items.Add(item);
            }

            public void Clear()
            {
                _items.Clear();
            }

            public bool Contains(T item)
            {
                return _items.Contains(item);
            }

            public void CopyTo(T[] array, int arrayIndex)
            {
                _items.CopyTo(array, arrayIndex);
            }

            public bool Remove(T item)
            {
                return _items.Remove(item);
            }

            public IEnumerator<T> GetEnumerator()
            {
                return _items.GetEnumerator();
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }

        }

        public class MyIList<T> : IList<T>
        {
            private List<T> _items = new List<T>();
            public T this[int index] { get => _items[index]; set => _items[index] = value; }
            public int Count => _items.Count;
            public bool IsReadOnly => false;
            public void Add(T item)
            {
                _items.Add(item);
            }
            public void Clear()
            {
                _items.Clear();
            }
            public bool Contains(T item)
            {
                return _items.Contains(item);
            }
            public void CopyTo(T[] array, int arrayIndex)
            {
                _items.CopyTo(array, arrayIndex);
            }
            public IEnumerator<T> GetEnumerator()
            {
                return _items.GetEnumerator();
            }
            public int IndexOf(T item)
            {
                return _items.IndexOf(item);
            }
            public void Insert(int index, T item)
            {
                _items.Insert(index, item);
            }
            public bool Remove(T item)
            {
                return _items.Remove(item);
            }
            public void RemoveAt(int index)
            {
                _items.RemoveAt(index);
            }
            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }

        public class myDictionary<TKey, TValue> : IDictionary<TKey, TValue>
        {
            private List<KeyValuePair<TKey, TValue>> _items = new List<KeyValuePair<TKey, TValue>>();

            public TValue this[TKey key]
            {
                get => _items.FirstOrDefault(kvp => kvp.Key.Equals(key)).Value;
                set
                {
                    var index = _items.FindIndex(kvp => kvp.Key.Equals(key));
                    if (index >= 0)
                    {
                        _items[index] = new KeyValuePair<TKey, TValue>(key, value);
                    }
                    else
                    {
                        _items.Add(new KeyValuePair<TKey, TValue>(key, value));
                    }
                }
            }
            public ICollection<TKey> Keys => _items.Select(kvp => kvp.Key).ToList();

            public ICollection<TValue> Values => _items.Select(kvp => kvp.Value).ToList();

            public int Count => _items.Count;

            public bool IsReadOnly => true;


            public void Add(TKey key, TValue value)
            {
                if (!_items.Any(kvp => kvp.Key.Equals(key)))
                {
                    _items.Add(new KeyValuePair<TKey, TValue>(key, value));
                }

            }
            public void Add(KeyValuePair<TKey, TValue> item)
            {
                if (!_items.Any(kvp => kvp.Key.Equals(item.Key)))
                {
                    _items.Add(item);
                }
            }

            public void Clear()
            {
                _items.Clear();
            }

            public bool Contains(KeyValuePair<TKey, TValue> item)
            {
                return _items.Contains(item);
            }

            public bool ContainsKey(TKey key)
            {
                return _items.Any(kvp => kvp.Key.Equals(key));
            }

            public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
            {
                if (array == null) throw new ArgumentNullException(nameof(array));
                if (arrayIndex < 0 || arrayIndex + _items.Count > array.Length) throw new ArgumentOutOfRangeException(nameof(arrayIndex));
                for (int i = 0; i < _items.Count; i++)
                {
                    array[arrayIndex + i] = _items[i];
                }
            }

            public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
            {
                return _items.GetEnumerator();
            }

            public bool Remove(TKey key)
            {
                var item = _items.FirstOrDefault(kvp => kvp.Key.Equals(key));
                if (item.Equals(default(KeyValuePair<TKey, TValue>))) return false;
                return _items.Remove(item);
            }

            public bool Remove(KeyValuePair<TKey, TValue> item)
            {
                return _items.Remove(item);
            }

            public bool TryGetValue(TKey key, out TValue value)
            {
                var item = _items.FirstOrDefault(kvp => kvp.Key.Equals(key));
                if (item.Equals(default(KeyValuePair<TKey, TValue>)))
                {
                    value = default;
                    return false;
                }
                value = item.Value;
                return true;
            }


            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }
    }
}