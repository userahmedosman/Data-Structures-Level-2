﻿using System;

namespace SortedListExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            SortedLis

            var sortedList = new SortedList<int, string>();
            sortedList.Add(2, "Zain");
            sortedList.Add(1, "Ahmed");
            sortedList.Add(3, "Mohammed");

            Console.WriteLine("Sorted List Count: " + sortedList.Count);
            Console.WriteLine("Sorted List Element: " + string.Join(", ", sortedList));

            using LINQ operation in SortedList<Tkey, Tval>

            var sortedList = new SortedList<int, string>();
            sortedList.Add(2, "Zain");
            sortedList.Add(1, "Ahmed");
            sortedList.Add(3, "Mohammed");

            //first way using contextual keywords

            var first = from kvp in sortedList
                        where kvp.Key == 1
                        select kvp;
            foreach (var kvp in first)
            {
                Console.WriteLine(kvp.Value);
            }
            // second way
            var second = sortedList.Where(kvp => kvp.Key == 2);

            foreach (var kvp in second) { Console.WriteLine(kvp.Value); }

            Advanced LINQ Operations using Groupby

           var sortedList = new SortedList<int, string>();
            sortedList.Add(2, "Banana");
            sortedList.Add(1, "Orange");
            sortedList.Add(3, "Wine");
            sortedList.Add(4, "Strawperry");
            sortedList.Add(5, "Mango");
            sortedList.Add(6, "Fig");

            var groupfruit = sortedList.GroupBy(x => x.Value.Length);

            foreach (var group in groupfruit)
            {
                {
                    Console.WriteLine(group.Key + "-----");
                }

                foreach (var item in group)
                {
                    {
                        Console.WriteLine(item.Value);
                    }
                }
            }

            SortedList<int, Employees> employees = new SortedList<int, Employees>();

            employees.Add(1, new Employees(1700, "Alice", "IT"));
            employees.Add(2, new Employees(2300, "Joe", "HR"));
            employees.Add(3, new Employees(1300, "Lora", "Customer Service"));
            employees.Add(4, new Employees(2900, "Mike", "IT"));
            employees.Add(5, new Employees(2000, "James", "Marketing"));
            employees.Add(6, new Employees(1500, "Dave", "IT"));
            employees.Add(7, new Employees(2100, "Alice", "Marketing"));


            var query = employees.Where(employee => employee.Value.department == "IT")
                                 .OrderByDescending(employee => employee.Value.salary)
                                 .Select(employee => employee.Value.name);
            foreach (var employee in query)
            {
                Console.WriteLine(employee);
            }
        }
    }
}