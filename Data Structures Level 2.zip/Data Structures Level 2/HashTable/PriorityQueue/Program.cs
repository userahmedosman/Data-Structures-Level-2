﻿using System;

namespace HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            HashTable
            Hashtable hashTable = new Hashtable();

            hashTable.Add("a", 1);
            hashTable.Add("b", 2);
            hashTable.Add("c", 3);
            hashTable.Add("d", 4);

            Console.WriteLine("Value: " + hashTable["a"]);


            // Removing a value

            hashTable.Remove("a");

            foreach (DictionaryEntry entry in hashTable)
            {
                Console.WriteLine(entry.Key + " - " + entry.Value);
            }
        }
    }
}