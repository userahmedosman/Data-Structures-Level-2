﻿using System;

namespace ArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
           // ArrayList

          ArrayList arrayList1 = new ArrayList();

            arrayList.Add("data");
            arrayList.Add(1);
            arrayList.Add('A');
            arrayList.Add(true);

            foreach (var element in arrayList)
            {
                Console.WriteLine(element);
            }


            ArrayList arrayList = new ArrayList() { 7, 1, 3, 9, 5, 2, 6, 8, 10, 5 };

            var evenNums = arrayList.Cast<int>().Where(x => x % 2 == 0);

            Console.WriteLine("Even Numbers: " + string.Join(", ", evenNums));

            var max = arrayList.OfType<int>().Max();
            Console.WriteLine("Largest Number: " + max.ToString());

            var min = arrayList.OfType<int>().Min();
            Console.WriteLine("Smallest Number: " + min.ToString());

            var sum = arrayList.OfType<int>().Sum();
            Console.WriteLine("Total Sum: " + sum.ToString());

            var avg = arrayList.OfType<int>().Average();
            Console.WriteLine("Average Number: " + avg.ToString());

            var count = arrayList.OfType<int>().Count();
            Console.WriteLine("Numbers Count: " + count.ToString());

            arrayList.Sort();



            foreach (int num in arrayList)
            {
                Console.WriteLine(num.ToString());
            }

            ArrayList arlist = new ArrayList() { 1, 2, 2, 3, 3, 1, 2, 4, 2, 3, 4, 5, 6, 7, 4, 5, 5, 6, 7, 7, 7, 7, 8 };

            int targetNum = 2;

            var numCount = arlist.Cast<int>().Count(num => num == targetNum);

            Console.WriteLine($"Number {targetNum} has been repeated {numCount} time");
        }
    }
}