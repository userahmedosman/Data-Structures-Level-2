﻿using System;

namespace ArrayExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            Array

        int[] arr = new int[5];


            arr[0] = 1;
            Console.WriteLine("Array List: " + string.Join(", ", arr));

            int[] arrnums = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };

            for (int i = 0; i < arrnums.Length; i++)
            {
                Console.WriteLine($"Element at index {i} = " + arrnums[i]);
            }

            int[] randomNums = { 1, 2, 6, 4, 5, 9, 10, 3, 7, 8 };
            Console.WriteLine("Random List Num: " + string.Join(", ", randomNums));

            Array.Sort(randomNums);

            Console.WriteLine("Sotred Array List Num: " + string.Join(", ", randomNums));

            // Searching for an element, this will return the index for the element you searched for.
            int index = Array.IndexOf(randomNums, 4);

            Console.WriteLine("Index of 4 is: " + index);

            Multidimentional 2D Array

        int[,] multi2d = { { 1, 2, 3, }, { 4, 5, 6, }, { 7, 8, 9 } };

            for (int i = 0; i < multi2d.GetLength(0); i++)
            {

                Console.WriteLine($"Group {i + 1}: ");
                for (int j = 0; j < multi2d.GetLength(1); j++)
                {
                    Console.Write(multi2d[i, j] + ", ");
                }
                Console.WriteLine();
            }

            Copying One Array to another


        int[] ar1 = { 1, 2, 3 };
            int[] ar2 = { 4, 5, 6 };


            Array.Copy(ar2, ar1, ar2.Length);


            Console.WriteLine("Array items after copying: " + string.Join(", ", ar1));

            Using LINQ with Array

        int[] ints = { 1, -2, 3, 4, -5, 6, 7, -8, 9, 10, -10 };

            //filtering
            var evenNums = ints.Where(x => x % 2 == 0);
            int max = ints.Max(x => x);
            int min = ints.Min(x => x);
            int sum = ints.Sum(x => x);
            double avg = ints.Average(x => x);

            Console.WriteLine("Even Nums: " + string.Join(", ", evenNums));
            Console.WriteLine("Biggest Num: " + max);
            Console.WriteLine("Smallest Num: " + min);
            Console.WriteLine("Total sum: " + sum);
            Console.WriteLine("Average: " + avg);

            Adavanced LINQ Operations on Array

            var people = new[]
            {
            new { Name = "Ahmed", Age = 25 },
            new { Name = "Ibrahim", Age = 28 },
            new { Name = "Jamal", Age = 32 },
            new { Name = "Khaled", Age = 32 },
            new { Name = "Saleh", Age = 25 },
            new { Name = "Sara", Age = 28 },
            new { Name = "Mohammed", Age = 19 },
            new { Name = "Muna", Age = 22 },
            new { Name = "Ismael", Age = 28 },
            new { Name = "Maher", Age = 36 },


            };


            var groupByAge = people.GroupBy(person => person.Age)
                                   .Select(x => new { Age = x.Key, People = x.OrderBy(p => p.Name) });
            foreach (var group in groupByAge)
            {
                Console.WriteLine(group.Age + ":");

                foreach (var person in group.People)
                {
                    Console.WriteLine($"{person.Name}");
                }
            }

            Advanced LINQ Operations on Arrays - Joining and Projection

        var employees = new[]
        {
            new { id = 1, name = "Ahmed", departmentId = 1 },
            new { id = 2, name = "Iman", departmentId = 3 },
            new { id = 3, name = "Salwa", departmentId = 3 },
            new { id = 4, name = "Ikram", departmentId = 4 },
            new { id = 5, name = "Munir", departmentId = 5 },
            new { id = 6, name = "Jaad", departmentId = 3 },
            new { id = 7, name = "Emaad", departmentId = 4 },
            new { id = 8, name = "Riham", departmentId = 4 },
            new { id = 9, name = "Ibrahim", departmentId = 5 },
            new { id = 10, name = "Jamal", departmentId = 2 },
            new { id = 11, name = "Zeynab", departmentId = 6 },
            new { id = 12, name = "Sumeya", departmentId = 4 },
        };

            var departments = new[]
            {
            new { departmentId = 1, department = "CTO" },
            new { departmentId = 2, department = "CEO" },
            new { departmentId = 3, department = "Backend Enginner" },
            new { departmentId = 4, department = "Frontend Enginner" },
            new { departmentId = 5, department = "Production Manager" },
            new { departmentId = 6, department = "Node Resources" },
        };

            var detail = employees.Join(departments, employee => employee.departmentId,
                                                     department => department.departmentId,
                                                     (employee, department) => new { employee.name, department.department });
            // Or

            var employeeDetails = from e in employees
                                  join d in departments on e.departmentId equals d.departmentId
                                  select new { e.name, Department = d.department };



            foreach (var employee in detail)
            {
                Console.WriteLine($"Name: {employee.name} Department: {employee.department}");
            }
        }
    }
}