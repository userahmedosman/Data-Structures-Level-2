﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        List<int> list = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        list.Add(10);

        Console.WriteLine("List after adding 10: " + string.Join(", ", list));

        list.Insert(0, 0);

        Console.WriteLine("List after inserting 0 at index 0: " + string.Join(", ", list));

        list.InsertRange(5, new List<int> { 100, 1000 });

        Console.WriteLine("List after inserting 100 and 1000 after index 5 " + string.Join(",", list));

        list.Remove(0);

        Console.WriteLine("List after removing num 5: " + string.Join(", ", list));

        list.RemoveAt(0);

        Console.WriteLine("List after removing num at index 0: " + string.Join(",", list));

        list.RemoveAll(x => x == 5);

        Console.WriteLine("List after removing all even numbers: " + string.Join(",", list));

        list.Clear();

        Console.WriteLine("List after clear: " + list.Count);

        for (int i = 0; i < list.Count; i++)
        {
            Console.Write(list[i]);
            if (i == list.Count - 1)
            {
                break;
            }
            Console.Write(", ");
        }

        foreach (int num in list)
        {
            Console.WriteLine(num + "-");
        }

        list.ForEach(x => Console.WriteLine(x));

        Console.WriteLine("List sum: " + list.Sum());
        Console.WriteLine("List Average: " + list.Average());
        Console.WriteLine("List Max: " + list.Max());
        Console.WriteLine("List Min: " + list.Min());
        Console.WriteLine("List count: " + list.Count());

        //filtering

        Console.WriteLine("Even nums: " + string.Join(", ", list.Where(n => n % 2 == 0)));
        Console.WriteLine("Odd nums: " + string.Join(", ", list.Where(n => n % 2 != 0)));
        Console.WriteLine("Greater than 5 nums: " + string.Join(", ", list.Where(n => n > 5)));
        Console.WriteLine("every second num: " + string.Join(", ", list.Where((n, index) => index % 2 == 0)));
        Console.WriteLine("Numbers greater than 3 and smaller than 8: " + string.Join(", ", list.Where((n => n > 3 && n < 8))));

        // sorting
        List<int> nums = new List<int> { 21, -4, 10, 200, 11, 5, 4, 38, 88, 123, -8, 0, 2 };
        nums.Sort(); // sorts ascending 
        Console.WriteLine("Ascending sort: " + string.Join(", ", nums));
        nums.Reverse(); // sort descending
        Console.WriteLine(("Descending sort: " + string.Join(", ", nums)));

        //// using LINQ
        nums = new List<int> { 21, -4, 10, 200, 11, 5, 4, 38, 88, 123, -8, 0, 2 };
        Console.WriteLine("Ascending LINQ: " + string.Join(", ", nums.OrderBy(n => n)));
        Console.WriteLine("Deceding LINQ: " + string.Join(", ", nums.OrderByDescending(n => n)));

        // searching

        Console.WriteLine("Contains: " + string.Join(", ", nums.Contains(14) == true ? "Yes exists" : "No not exist"));
        Console.WriteLine("Exists: " + string.Join(", ", nums.Exists(n => n > 200) == true ? "Yes exist" : "No not exist"));
        Console.WriteLine("Find: " + string.Join(", ", nums.Find(n => n < 4)));
        Console.WriteLine("Find All: " + string.Join(", ", nums.FindAll(n => n < 4)));

        // List with customObjects

        List<Person> people = new List<Person> {
            new Person(20, "Ahmed"),
            new Person(18, "Lina"),
            new Person(28, "Jamal"),
            new Person(17, "Yamal"),
            new Person(30, "Sara"),
            new Person(24, "Buran")
        };

        //loop over list
        foreach (Person person in people)
        {
            Console.WriteLine("Name: " + person.name + " Age: " + person.age);
        }

        //find specific person
        Person person2 = people.Find(n => n.name == "Lina");

        if (person2 != null)
        {
            Console.WriteLine($"{person2.name} Age: {person2.age}");
            person2.age = 20;
            Console.WriteLine($"{person2.name} Updated age is: {person2.age}");
        }
        else
        {
            Console.WriteLine("Name not found");
        }

        // find all people that meet a specific condition
        List<Person> peopleOver30 = people.FindAll(age => age.age >= 30);

        foreach (var person in peopleOver30)
        {
            Console.WriteLine(person.name + " - " + person.age);
        }

        // check person using any
        bool getPerson = people.Any(name => name.name == "alice");

        if (getPerson)
        {
            Console.WriteLine("alice is alive");
        }
        else
        {
            Console.WriteLine("who is alice");
        }

        // check person using exist

        bool getPerson2 = people.Exists(name => name.name == "Lina");
        if (getPerson2)
        {
            Console.WriteLine("Lina is exist");
        }
        else
        {
            Console.WriteLine("who is Lina");
        }

        // remove all people that meet specific condition

        people.RemoveAll(age => age.age <= 17);

        foreach (var person in people)
        {
            Console.WriteLine("After removing under-age");
            Console.WriteLine(person.name + " - " + person.age);
        }

        //convert list to array

        int[] ints = nums.ToArray();

        Console.WriteLine("Array: " + string.Join(", ", ints));

        List<int> nums2 = ints.ToList<int>();
    }
}

public class Person
{
    public int age;
    public string name;
    public Person(int age, string name)
    {
        this.age = age;
        this.name = name;
    }
}

