﻿using System;

namespace BoxingUnBoxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int valType = 10;
            object objType = valType; // Boxing

            objType = "hajo";
            string unboxedValType = (string)objType; // Unboxing


            Console.WriteLine("Unboxed Value: " + unboxedValType);
        }
    }
}