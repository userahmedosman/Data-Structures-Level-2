﻿using System;

namespace SortedSetExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            SortedSet
        SortedSet<int> sortedSet = new SortedSet<int>() { 5, 3, 4, 2, 1, 6, 7, 9, 10, 8 };

            Console.WriteLine($"SortedSet: " + string.Join(", ", sortedSet));

            int target = 4;

            if (sortedSet.Contains(target))
            {
                Console.WriteLine($"{target} exists");
                sortedSet.Remove(target);
            }

            Console.WriteLine($"SortedSet after removing {target}: " + string.Join(", ", sortedSet));

            //filtering

            var filter = sortedSet.Where(x => x > target);
            Console.WriteLine($"SortedSet greater than {target}: " + string.Join(", ", filter));

            //sum

            var sum = sortedSet.Sum(x => x);
            Console.WriteLine($"Total Sum of SortedSet: " + string.Join(", ", sum));


            // sorting on decending order

            var decending = sortedSet.OrderByDescending(x => x);
            Console.WriteLine($"SortedSet sorted decending: " + string.Join(", ", decending));

            // Maximum and minimum elements
            var maxElement = sortedSet.Max();
            var minElement = sortedSet.Min();
            Console.WriteLine("Maximum element: " + maxElement);
            Console.WriteLine("Minimum element: " + minElement);

            var oddNumsSquared = sortedSet.Where(x => x % 2 != 0)
                                          .Select(x => x * x);

            Console.WriteLine($"Squared Odd Numbers: " + string.Join(", ", oddNumsSquared));

            SortedSet<int> sortedSet1 = new SortedSet<int>() { 1, 3, 2, 4, 6, 5 };
            SortedSet<int> sortedSet2 = new SortedSet<int>() { 1, 2, 4, 5, 6, 7, 8, 9, 10 };
            SortedSet<int> sortedSet3 = new SortedSet<int>() { 3, 2, 1, 4, 6, 5, };

            //SortedSet Union
            var union = sortedSet1.Union(sortedSet2);

            Console.WriteLine($"Union sortedSet : " + string.Join(", ", union));

            //SortedSet Intersection
            var intersection = sortedSet1.Intersect(sortedSet2);
            Console.WriteLine($"sortedSet intersection : " + string.Join(", ", intersection));

            //SortedSet Difference

            var difference = sortedSet1.Except(sortedSet2);
            Console.WriteLine($"sortedSet difference : " + string.Join(", ", difference));

            //Subset, Superset and EqualsTo

            bool subset = sortedSet1.IsSubsetOf(sortedSet2);
            Console.WriteLine("SortedSet1 is Subset of SoredSet2: " + subset); // false
            bool subset2 = sortedSet1.IsSubsetOf(sortedSet3);
            Console.WriteLine("SortedSet1 is Subset of SoredSet3: " + subset2); // true

            bool superset = sortedSet3.IsSupersetOf(sortedSet1);
            Console.WriteLine("SortedSet1 is Subset of SoredSet2: " + superset); // true
            bool superset2 = sortedSet1.IsSupersetOf(sortedSet3);
            Console.WriteLine("SortedSet1 is Subset of SoredSet3: " + superset2); // true

            bool equals = sortedSet3.SetEquals(sortedSet1);
            Console.WriteLine("SortedSet3 SetEquals SoredSet1: " + superset); // true
            bool equals2 = sortedSet1.SetEquals(sortedSet2);
            Console.WriteLine("SortedSet1 SetEquals SortedSet2: " + equals2); // false
        }
    }
}