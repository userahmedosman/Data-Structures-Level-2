﻿using System;

namespace LinkedListExamples {
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList<int> linkedlist = new LinkedList<int>();
            // adding
            linkedlist.AddLast(1);
            linkedlist.AddLast(2);
            linkedlist.AddLast(3);
            linkedlist.AddLast(4);
            linkedlist.AddLast(5);
            linkedlist.AddLast(6);

            Console.WriteLine("Linked list items: " + string.Join(", ", linkedlist));
            //deleting
            linkedlist.Remove(1);

            Console.WriteLine("Linked list items after removing first item: " + string.Join(", ", linkedlist));

            //searching

            if (linkedlist.Contains(1)) Console.WriteLine("Yes item exists");
            else Console.WriteLine("item not found");
        }
    }
}