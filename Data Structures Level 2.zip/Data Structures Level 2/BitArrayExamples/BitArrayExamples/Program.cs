﻿using System;

namespace BitArrayExamples {
    class Program
    {
        static string BitToString(BitArray bitArray)
        {
            char[] chars = new char[bitArray.Length];
            for (int i = 0; i < bitArray.Length; i++)
            {
                chars[i] = bitArray[i] ? '1' : '0';
            }
            return new string(chars);
        }

        static string BitToString(bool[] bitArray)
        {
            char[] chars = new char[bitArray.Length];
            for (int i = 0; i < bitArray.Length; i++)
            {
                chars[i] = bitArray[i] ? '1' : '0';
            }
            return new string(chars);
        }
        static void Main(string[] args)
        {
           // BitArrays

              BitArray b1 = new BitArray(10);

            Console.WriteLine("BitArray content: " + BitToString(b1));

            bool[] bools = { true, false, true, false, false, true, true, false, false, true };

            Console.WriteLine("boolean array content: " + BitToString(bools));

            byte[] bites = { 0x44, 0x77, 0x14 }; //hexadecmial

            BitArray b2 = new BitArray(bites);

            Console.WriteLine("From byte to BitArray: " + BitToString(b2));

            //Basic operations

            BitArray bitArray = new BitArray(8);

            Console.WriteLine("BitArray content: " + BitToString(bitArray));

            bitArray.Set(3, true);
            bitArray.Set(4, true);

            Console.WriteLine("BitArray content after Set: " + BitToString(bitArray));

            bitArray.SetAll(true);

            Console.WriteLine("BitArray content after SetAll(true): " + BitToString(bitArray));
        }


        Bitwise Operation using BitArray

   BitArray bit1 = new BitArray(new bool[] { true, false, false, true, false, true });
    BitArray bit2 = new BitArray(new bool[] { false, true, false, false, true, true });


    BitArray bitwiseAnd = new BitArray(bit1);
    bitwiseAnd.And(bit2);
Console.WriteLine("Bit1 intial values: " + BitToString(bit1));
Console.WriteLine("Bit2 inital values: " + BitToString(bit2));
Console.WriteLine("-------------------------------");
Console.WriteLine("Bitwise AND:        " + BitToString(bitwiseAnd));

Console.WriteLine("\n");

BitArray bitwiseOr = new BitArray(bit1);
    bitwiseOr.Or(bit2);
Console.WriteLine("Bit1 intial values: " + BitToString(bit1));
Console.WriteLine("Bit2 inital values: " + BitToString(bit2));
Console.WriteLine("-------------------------------");
Console.WriteLine("Bitwise OR:         " + BitToString(bitwiseOr));

Console.WriteLine("\n");

BitArray bitwiseNot = new BitArray(bit1);
    bitwiseNot.Not();
Console.WriteLine("Bit1 intial values: " + BitToString(bit1));
Console.WriteLine("-------------------------------");
Console.WriteLine("Bitwise NOT:        " + BitToString(bitwiseNot));

Console.WriteLine("\n");

BitArray bitwiseXor = new BitArray(bit1);
    bitwiseXor.Xor(bit2);
Console.WriteLine("Bit1 intial values: " + BitToString(bit1));
Console.WriteLine("Bit2 inital values: " + BitToString(bit2));
Console.WriteLine("-------------------------------");
Console.WriteLine("Bitwise XOR:        " + BitToString(bitwiseXor));
        }
    }
}