﻿using System;

namespace GeneralTree
{
    class Program
    {
        static void Main(string[] args)
        {
            // Tree data structure

            Tree<string> cto = new Tree<string>("CTO");
            Node<string> chiefArch = new Node<string>("Chief Architect 1");

            Node<string> networEngineeringManager = new Node<string>("Network Engineering Manager");
            Node<string> networkEngineer1 = new Node<string>("Network Engineer 1");
            Node<string> networkEngineer2 = new Node<string>("Network Enginner 2");
            Node<string> DevopsArch = new Node<string>("DevOps Architect");
            Node<string> devops1 = new Node<string>("DevOps Engineer 1");
            Node<string> devops2 = new Node<string>("DevOps Engineer 2");
            Node<string> devops3 = new Node<string>("DevOps Engineer 3");
            Node<string> techlead = new Node<string>("Tech Lead");
            Node<string> SeniorBackend = new Node<string>("Senior Backend Developer");
            Node<string> backend1 = new Node<string>("Backend Developer 1");
            Node<string> backend2 = new Node<string>("Backend Developer 2");
            Node<string> backend3 = new Node<string>("Backend Developer 3");
            Node<string> backend4 = new Node<string>("Backend Developer 4");
            Node<string> backend5 = new Node<string>("Backend Developer 5");

            Node<string> SeniorFrontEnd = new Node<string>("Senior FrontEnd Developer");
            Node<string> frontEnd1 = new Node<string>("FrontEnd Developer 1");
            Node<string> frontEnd2 = new Node<string>("FrontEnd Developer 2");
            Node<string> frontEnd3 = new Node<string>("FrontEnd Developer 3");
            Node<string> frontEnd4 = new Node<string>("FrontEnd Developer 4");

            cto.Root.AddChild(chiefArch);
            chiefArch.AddChild(networEngineeringManager);
            networEngineeringManager.AddChild(networkEngineer1);
            networEngineeringManager.AddChild(networkEngineer2);
            chiefArch.AddChild(DevopsArch);
            DevopsArch.AddChild(devops1);
            DevopsArch.AddChild(devops2);
            DevopsArch.AddChild(devops3);
            chiefArch.AddChild(techlead);

            techlead.AddChild(SeniorBackend);
            SeniorBackend.AddChild(backend1);
            SeniorBackend.AddChild(backend2);
            SeniorBackend.AddChild(backend3);
            SeniorBackend.AddChild(backend4);
            SeniorBackend.AddChild(backend5);

            techlead.AddChild(SeniorFrontEnd);
            SeniorFrontEnd.AddChild(frontEnd1);
            SeniorFrontEnd.AddChild(frontEnd2);
            SeniorFrontEnd.AddChild(frontEnd3);
            SeniorFrontEnd.AddChild(frontEnd4);

            // Print the tree structure

            PrintTree(cto.Root);


            bool isfound = Find("DBA", cto.Root);

            if (isfound)
            {
                Console.WriteLine("Yes Found");
            }
            else
            {
                Console.WriteLine("No Not Found");
            }

        }
    }
    public class Node<T>
    {
        public T Name { get; set; }

        public List<Node<T>> Children { get; set; }

        public Node(T name)
        {
            this.Name = name;
            this.Children = new List<Node<T>>();
        }

        public void AddChild(Node<T> child)
        {
            Children.Add(child);
        }
    }

    public class Tree<T>
    {
        public Node<T> Root { get; set; }
        public Tree(T rootName)
        {
            Root = new Node<T>(rootName);
        }



    }

    public static void PrintTree<T>(Node<T> Node, string indent = "")
        {
            Console.WriteLine(indent + Node.Name);
            foreach (var child in Node.Children)
            {
                PrintTree(child, indent + "  ");
            }
        }
        public static bool Find<T>(T name, Node<T>? node)
        {

            if (node.Name.Equals(name))
            {
                return true;
            }
            foreach (var child in node.Children)
            {
                if (Find(name, child))
                {
                    return true;
                }
            }
            return false;
        }

    public class Order : IComparable<Order>
    {
        public Customer? Buyer { get; set; }

        public int CompareTo(Order? other)
        {
            if (other == null) return 1;
            return this.Buyer.CompareTo(other.Buyer); // delegation, not recursion
        }
    }

    public class Customer : IComparable<Customer>
    {
        public string Name { get; set; }

        public int CompareTo(Customer? other)
        {
            if (other == null) return 1;
            return this.Name.CompareTo(other.Name); // for example
        }
    }


    public class Students : IComparable<Students>
    {
        public int id { get; set; }
        public string name { get; set; }
        public int age { get; set; }
        public Students(int id, string name, int age)
        {
            this.id = id;
            this.name = name;
            this.age = age;
        }

        public int CompareTo(Students? other)
        {
            if (other == null) return 1;
            return this.name.CompareTo(other.name);
        }
    }
}