﻿using System;

namespace HashSet
{
    class Program
    {
        static void Main(string[] args)
        {
            HashSet<T>

        HashSet<int> set = new HashSet<int>();
            set.Add(1);
            set.Add(2);
            set.Add(3);
            set.Add(4);
            set.Add(3); // will be ignored automatically
            set.Add(4); // will be ignored automatically

            foreach (var s in set)
            {
                Console.WriteLine(s);
            }

            HashSet<string> fruits = new HashSet<string>() { "Apple", "Orange", "Mango" };


            if (fruits.Contains("Apple"))
            {
                Console.WriteLine("Apple exist");
            }
            else
            {
                Console.WriteLine("Apple is not available");
            }

            Console.WriteLine("Total items: " + fruits.Count);

            fruits.Remove("Orange");

            Console.WriteLine("Total items count after removing Orange: " + fruits.Count);

            foreach (var fruit in fruits) { Console.WriteLine(fruit); }

            removing dublicates from array using hashset

        int[] arr = { 1, 2, -4, 3, 4, -5, 6, 7, 4, 2, 3, 2, 2, 3, 4, 5, 4, 6, 5, 2, 1, 1, 3, 1, 4, 2 };


            HashSet<int> filter = new HashSet<int>(arr);

            Console.WriteLine("Unique array items: " + string.Join(", ", filter));

            using LINQ with HashSet<T>


        HashSet<int> ints = new HashSet<int>() { 1, -2, 3, 4, -5, 6, 7, -8, 9, 10, 11, 12, 14, 16, 18, 20, 21, 23, 22 };

            var evennums = ints.Where(x => x % 2 == 0);

            Console.WriteLine("Even nums: " + string.Join(", ", evennums));

            var hashsum = ints.Sum(x => x);
            Console.WriteLine("Total Sum: " + hashsum);


            HashSet<string> names = new HashSet<string>() { "Lana", "Fred", "Samuel", "Joe", "Rozalina", "Li", "James", "Jhonson" };

            var namesStartingWithJ = names.Where(x => x.StartsWith("J"));

            Console.WriteLine("Names Starting with J: " + string.Join(", ", namesStartingWithJ));

            var namesWith3Chars = names.Where(name => name.Length < 3);
            Console.WriteLine("Names with less than 3 chars: " + string.Join(", ", namesWith3Chars));

            Union two hashsets

        HashSet<int> set = new HashSet<int>() { 1, 2, 3 };
            HashSet<int> union = new HashSet<int>() { 3, 4, 5, 6 };


            union.UnionWith(set);
            var ordered = union.OrderBy(x => x);

            Console.WriteLine("Union: " + string.Join(", ", ordered));

            set.IntersectWith(union);

            Console.WriteLine("Intersections: " + string.Join(", ", set));

            var expect = set.Except(union); // holds values that does not exist in union

            Console.WriteLine("Except : " + string.Join(", ", expect));

            var symmetricexcept = set.Except(union).Union(union.Except(set)); // removes any similar item in both hashsets

            Console.WriteLine("Symmetric Exception: " + string.Join(", ", symmetricexcept));


            Comparing HashSets

            HashSet<int> set1 = new HashSet<int>() { 1, 2, 3, 4 };
            HashSet<int> set2 = new HashSet<int>() { 1, 2, 3, 4 };
            HashSet<int> set3 = new HashSet<int>() { 4, 5, 5, 6 };


            Console.WriteLine("set1 vs set2: " + set1.SetEquals(set2));
            Console.WriteLine("set1 vs set3: " + set1.SetEquals(set3));

            HashSet<int> set1 = new HashSet<int>() { 1, 2 };
            HashSet<int> set2 = new HashSet<int>() { 1, 2, 3, 4 };
            HashSet<int> set3 = new HashSet<int>() { 5, 6, 7 };

            Console.WriteLine("is Subset: " + set1.IsSubsetOf(set2)); // true
            Console.WriteLine("is Superset: " + set2.IsSupersetOf(set1)); // true

            Console.WriteLine("Overlaps: " + set1.Overlaps(set2)); //Ture
            Console.WriteLine("Overlaps: " + set3.Overlaps(set1)); //False
        }
    }
}