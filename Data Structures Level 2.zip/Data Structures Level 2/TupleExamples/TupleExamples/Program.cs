﻿using System;

namespace Tubles
{
    class Program
    {
        static void Main(string[] args)
        {
            Tubles

        (string, int, bool) tuble = ("Ahmed", 26, true);


            Console.WriteLine("Name: " + tuble.Item1);
            Console.WriteLine("Age: " + tuble.Item2);
            Console.WriteLine("Single: " + tuble.Item3);

            // tuble function

            var tubleFunc = GetUserInfo("Ahmed", 25, "Software Engineer");

            Console.WriteLine("Name: " + tubleFunc.Item1);
            Console.WriteLine("Age: " + tubleFunc.Item2);
            Console.WriteLine("Job: " + tubleFunc.Item3);

            //LINQ in tubles


            List<(int id, string name, int age)> people = new List<(int id, string name, int age)>()
        {
            (1, "Mohammed", 29),
            (2, "Salem", 18),
            (3, "Ikram", 32),
            (4, "Randa", 22)
        };


            var under30 = people.Where(age => age.age < 30).Select(names => names.name);
            Console.WriteLine("People Under 30: " + string.Join(", ", under30));

            var totalAgeSum = people.Sum(age => age.age);
            var ageAvg = people.Average(age => age.age);
            var biggest = people.Max(age => age.age);
            var smallest = people.Min(age => age.age);

            Console.WriteLine("Total age sum: " + totalAgeSum);
            Console.WriteLine("Average Age: " + ageAvg);
            Console.WriteLine("biggest age: " + biggest);
            Console.WriteLine("smallest age: " + smallest);
        }
    }
}