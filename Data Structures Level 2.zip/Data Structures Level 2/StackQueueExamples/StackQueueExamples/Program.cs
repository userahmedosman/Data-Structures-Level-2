﻿using System;

namespace StackQueueExamples
{
       class Program
    {
        static void Main(string[] args)
        {
            Stack<T>

            Stack<int> stack = new Stack<int>();

            // adding item to stack
            stack.Push(1);
            stack.Push(2);
            stack.Push(3);
            stack.Push(4);

            Console.WriteLine("Current Stack itmes: " + string.Join(", ", stack));

            // getting item in the top
            Console.WriteLine("stack item in the top: " + stack.Peek());

            // removing item from the stack
            Console.WriteLine("Removed: " + stack.Pop());
            Console.WriteLine("Removed: " + stack.Pop());
            Console.WriteLine("Removed: " + stack.Pop());

            Console.WriteLine("Current stack items count: " + stack.Count());

            // clearing the stack

            stack.Clear();

            Console.WriteLine("stack items count after clear: " + stack.Count());

            Queue<T>


        Queue<string> queue = new Queue<string>();


            // Enqueueing elements into the queue
            queue.Enqueue("Alice");
            queue.Enqueue("Bob");
            queue.Enqueue("Charlie");
            queue.Enqueue("Diana");
            queue.Enqueue("Mark");

            Console.WriteLine("Queue line: " + string.Join(", ", queue));

            // Peeking at the first element
            Console.WriteLine("First in line: " + queue.Peek());


            // Dequeueing elements from the queue
            Console.WriteLine("Served: " + queue.Dequeue());
            Console.WriteLine("Served: " + queue.Dequeue());
            Console.WriteLine("Served: " + queue.Dequeue());
            Console.WriteLine("Served: " + queue.Dequeue());
            Console.WriteLine("Served: " + queue.Dequeue());


            // Checking if the queue is empty
            if (queue.Count == 0)
            {
                Console.WriteLine("Queue is empty.");
            }
            else
            {
                Console.WriteLine("First in line: " + queue.Peek());
            }


            // Clearing the queue
            queue.Clear();
        }
    }
}